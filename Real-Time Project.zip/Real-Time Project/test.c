#include <stdio.h>
#include <signal.h>
#include <unistd.h>
//#include <unistd.h>
int ctrl_c_count = 0;
void (* old_handler)(int);
void ctrl_c(int);
void main () {
    execl("parent","");
}