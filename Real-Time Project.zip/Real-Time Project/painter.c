#include "defines.h"

int main(){
    printf("I am painter\n");
}