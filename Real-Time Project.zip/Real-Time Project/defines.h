#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <signal.h>
#include <sys/types.h>
#include <sys/wait.h>
#define A1 2
#define A2 4
#define A3 6	// these values can be replaced later for better speeds
#define A4 8
#define A5 10