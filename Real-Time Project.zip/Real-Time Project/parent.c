#include "defines.h"


int scoredboard[2] = {0,0};
void score_0(int signum){
	scoredboard[0]++;
	printf("team 0 = %d\n", scoredboard[0]);
}
void score_1(int signum){
	scoredboard[1]++;
	printf("team 1 = %d\n", scoredboard[1]);
}
int main(int argc, char **argv){
	pid_t pid[11];
	pid_t temp_pid;
	
	int i;
	int position;
	short local_id = 12; // this variable lets each process know what number it is
	short team = 3; // team = 0 or team  = 1, else not a player, 3 is parent, 4 is painter;

	int rounds=5;
	if (argc == 2){
		rounds = atoi(argv[1]);
	} else if (argc > 2){
		perror("use: ./parent [number of rounds]\n");
	}
	printf("I am the parent process and my ID is %d\n", getpid());
	printf("I will now create the 10 player processes and an extra drawer process\n");

	temp_pid = fork();
	pid[0] = temp_pid;

	if (temp_pid == 0){
		printf("[C0] and my ID is %d\n", getpid());
		position = A1;
		team = 0;
		local_id = 0;
	} else {
		for (int i = 1; i < 11; i++){
			if (temp_pid != 0){ //this is the parent process will want to save child ID
					temp_pid = fork();
					if (temp_pid == -1){
						printf("fork failed");
						exit(1);
					}else if (temp_pid != 0){
						pid[i] = temp_pid;
						printf("[P] child %d has PID %d\n", i, temp_pid);
					}else{//this is a child, we need to tell it its starting position
						local_id = i;
						if (i < 5){
							team  = 0;
							printf("[C%d] my ID is %d on team 0\n\n", local_id, getpid());
						} else if ( i >= 5 && i <= 9){
							team = 1;
							printf("[C%d] my ID is %d on team 1\n\n", local_id, getpid());
						} else {
							team = 4;
							printf("[C%d] my ID is %d I am the painter child\n\n", local_id, getpid());
						}
					}
			}
		}
	}
	// parent process has created all processes and knows there IDs
	// all children know their numbers and as such can do individual work

	if (team == 3){ //this is the parent process work section
	/*
		parent process:
		sends SIGINT Signal to runner children so they start running
		waits for SIGUSR1 and SIGUSR2 to add tot the scoreboard
	*/
		signal(SIGUSR1, score_0);
		signal(SIGUSR2, score_1);
		int i = 0;
		while (rounds > 0){
			i=0;
			while (i < 10){
				kill (pid[i], SIGINT); //tell all player processes to reset their positions and set their speeds
				i++;
			}
			sleep(0.1); //wait for all player processes to reset places and set new speeds
			kill(pid[0], SIGUSR1);
			kill(pid[5], SIGUSR1); // the starter runners for both teams to start running

			pause(); // wait for signal from process 5 or from process 10 (last two runnersq)
			
			rounds--;
			printf("rounds = %d\n", rounds);
		}

		if (scoredboard[0] > scoredboard[1]){
			printf("!!!TEAM 0 WINS!!!\n");
		} else if (scoredboard[0] < scoredboard[1]){
			printf("!!!TEAM 1 WINS!!!\n");
		} else{
			printf("TIE\n");
		}


	} else if (team == 4){ // this is the painter process work section(child)
		/*
		excpected behavior:
		receives signals from parent  and checks fifos filled by children
		then draws children in the position given
		might also need to draw running track
		*/	
		execl("painter", "");

	} else if (team == 1 || team == 0){ // this is the player processes section(children)
		/*
		excpected behavior:
		waits for signal from parent to start race
		all players send signals to parentm, and fill fifo with current position and local_id
		transaction should look something like {position, local_id}, maybe a string seperated with commas
		*/
		execl("child", "");

	} else{ // this should never be enter unless something is wrong with the code
		perror ("error, undefined team");
		exit(2);
	}


	if (team == 0){
		i=0;
		while (i < 11){
			printf("%d\n",kill(pid[i], SIGKILL)); //tell all player processes to reset their positions and set their speeds
			i++;
		}
	}
	

}
