#include "defines.h"

int main(){
    printf("I am child\n");
}